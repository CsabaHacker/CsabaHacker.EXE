﻿namespace CsabaNotepadSave
{
    partial class CsabaNotepadSave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CsabaNotepadSave));
            this.btnMore1 = new System.Windows.Forms.Button();
            this.btnMore = new System.Windows.Forms.Button();
            this.pnlMore = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn3dayfreevip = new System.Windows.Forms.Button();
            this.btnVip = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBorowse = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.pnlMore.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMore1
            // 
            this.btnMore1.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Blue;
            this.btnMore1.Location = new System.Drawing.Point(700, -3);
            this.btnMore1.Name = "btnMore1";
            this.btnMore1.Size = new System.Drawing.Size(105, 43);
            this.btnMore1.TabIndex = 13;
            this.btnMore1.Text = "More";
            this.btnMore1.UseVisualStyleBackColor = true;
            this.btnMore1.Click += new System.EventHandler(this.btnMore1_Click_1);
            // 
            // btnMore
            // 
            this.btnMore.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Blue;
            this.btnMore.Location = new System.Drawing.Point(700, -3);
            this.btnMore.Name = "btnMore";
            this.btnMore.Size = new System.Drawing.Size(105, 43);
            this.btnMore.TabIndex = 12;
            this.btnMore.Text = "More";
            this.btnMore.UseVisualStyleBackColor = true;
            this.btnMore.Click += new System.EventHandler(this.btnMore_Click_1);
            // 
            // pnlMore
            // 
            this.pnlMore.BackColor = System.Drawing.Color.Blue;
            this.pnlMore.Controls.Add(this.button1);
            this.pnlMore.Controls.Add(this.btn3dayfreevip);
            this.pnlMore.Controls.Add(this.btnVip);
            this.pnlMore.Location = new System.Drawing.Point(611, 38);
            this.pnlMore.Name = "pnlMore";
            this.pnlMore.Size = new System.Drawing.Size(194, 318);
            this.pnlMore.TabIndex = 11;
            this.pnlMore.Visible = false;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Green;
            this.button1.Location = new System.Drawing.Point(33, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 41);
            this.button1.TabIndex = 2;
            this.button1.Text = "Administrator";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn3dayfreevip
            // 
            this.btn3dayfreevip.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Green;
            this.btn3dayfreevip.Location = new System.Drawing.Point(33, 66);
            this.btn3dayfreevip.Name = "btn3dayfreevip";
            this.btn3dayfreevip.Size = new System.Drawing.Size(129, 49);
            this.btn3dayfreevip.TabIndex = 1;
            this.btn3dayfreevip.Text = "3 Day For Free Vip";
            this.btn3dayfreevip.UseVisualStyleBackColor = true;
            // 
            // btnVip
            // 
            this.btnVip.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Green;
            this.btnVip.Location = new System.Drawing.Point(33, 20);
            this.btnVip.Name = "btnVip";
            this.btnVip.Size = new System.Drawing.Size(129, 40);
            this.btnVip.TabIndex = 0;
            this.btnVip.Text = "Vip";
            this.btnVip.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Blue;
            this.btnClear.ImageKey = "(none)";
            this.btnClear.Location = new System.Drawing.Point(179, -3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(96, 43);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click_1);
            // 
            // btnBorowse
            // 
            this.btnBorowse.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Blue;
            this.btnBorowse.ImageKey = "(none)";
            this.btnBorowse.Location = new System.Drawing.Point(-4, -3);
            this.btnBorowse.Name = "btnBorowse";
            this.btnBorowse.Size = new System.Drawing.Size(91, 43);
            this.btnBorowse.TabIndex = 9;
            this.btnBorowse.Text = "Borowse";
            this.btnBorowse.UseVisualStyleBackColor = true;
            this.btnBorowse.Click += new System.EventHandler(this.btnBorowse_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Blue;
            this.btnSave.Location = new System.Drawing.Point(83, -3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 43);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click_1);
            // 
            // txtOutput
            // 
            this.txtOutput.BackColor = System.Drawing.Color.ForestGreen;
            this.txtOutput.Location = new System.Drawing.Point(-4, 38);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(809, 415);
            this.txtOutput.TabIndex = 7;
            this.txtOutput.Text = "";
            // 
            // CsabaNotepadSave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CsabaNotepadSave.Properties.Resources.Green;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMore1);
            this.Controls.Add(this.btnMore);
            this.Controls.Add(this.pnlMore);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnBorowse);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtOutput);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CsabaNotepadSave";
            this.Text = "CsabaNotepadSave";
            this.pnlMore.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMore1;
        private System.Windows.Forms.Button btnMore;
        private System.Windows.Forms.Panel pnlMore;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn3dayfreevip;
        private System.Windows.Forms.Button btnVip;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBorowse;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.RichTextBox txtOutput;
    }
}

