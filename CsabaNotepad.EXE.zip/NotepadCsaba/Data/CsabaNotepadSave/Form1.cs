﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsabaNotepadSave
{
    public partial class CsabaNotepadSave : Form
    {
        public CsabaNotepadSave()
        {
            InitializeComponent();
        }

        private void btnBorowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.txt)|*.txt";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.txt)|*.txt";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void btnMore_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = true;
            btnMore1.Visible = true;
            btnMore.Visible = false;
        }

        private void btnMore1_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = false;
            btnMore1.Visible = false;
            btnMore.Visible = true;
        }

        private void btnVip_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Comming Soon");
        }

        private void btn3dayfreevip_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\SaveFile\\SaveFileAdministrator\\bin\\Debug\\SaveFileAdministrator.exe");
            System.Windows.Forms.Application.Exit();
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtOutput.Clear();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.txt)|*.txt";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void btnMore1_Click_1(object sender, EventArgs e)
        {
            pnlMore.Visible = true;
            btnMore1.Visible = true;
            btnMore.Visible = false;
        }

        private void btnMore_Click_1(object sender, EventArgs e)
        {
            pnlMore.Visible = false;
            btnMore1.Visible = false;
            btnMore.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave(Administrator)\\bin\\Debug\\CsabaNotepadSave(Administrator).exe");
            System.Windows.Forms.Application.Exit();
        }
    }
}
