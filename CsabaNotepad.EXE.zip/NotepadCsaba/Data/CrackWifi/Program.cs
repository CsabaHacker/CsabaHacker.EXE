﻿using System.Net.Security;

Console.WriteLine("Press 'y' or 'n' Hello");

ConsoleKeyInfo cki = Console.ReadKey();

if (cki.Key.ToString() == "y")
{
    Console.WriteLine("Yes");
}
else
{
    Console.WriteLine("Yes Correct");
}


if (cki.Key.ToString() == "n")
{
    Console.WriteLine("No");
}
else
{
    Console.WriteLine("No Correct");
}

