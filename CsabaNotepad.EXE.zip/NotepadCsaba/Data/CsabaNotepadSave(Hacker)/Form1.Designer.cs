﻿namespace CsabaNotepadSave_Hacker_
{
    partial class CsabaNotepadSaveHacker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CsabaNotepadSaveHacker));
            this.btnBorowse = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnMore1 = new System.Windows.Forms.Button();
            this.btnMore = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnHacker = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.pnlMore = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cBh = new System.Windows.Forms.CheckBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.pnlMore.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBorowse
            // 
            this.btnBorowse.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnBorowse.Location = new System.Drawing.Point(-4, -3);
            this.btnBorowse.Name = "btnBorowse";
            this.btnBorowse.Size = new System.Drawing.Size(92, 43);
            this.btnBorowse.TabIndex = 36;
            this.btnBorowse.Text = "Borowse";
            this.btnBorowse.UseVisualStyleBackColor = true;
            this.btnBorowse.Click += new System.EventHandler(this.btnBorowse_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnClear.Location = new System.Drawing.Point(177, -3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(99, 43);
            this.btnClear.TabIndex = 35;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnMore1
            // 
            this.btnMore1.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnMore1.Location = new System.Drawing.Point(697, -3);
            this.btnMore1.Name = "btnMore1";
            this.btnMore1.Size = new System.Drawing.Size(105, 43);
            this.btnMore1.TabIndex = 34;
            this.btnMore1.Text = "More";
            this.btnMore1.UseVisualStyleBackColor = true;
            this.btnMore1.Click += new System.EventHandler(this.btnMore1_Click);
            // 
            // btnMore
            // 
            this.btnMore.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnMore.Location = new System.Drawing.Point(700, -3);
            this.btnMore.Name = "btnMore";
            this.btnMore.Size = new System.Drawing.Size(105, 43);
            this.btnMore.TabIndex = 33;
            this.btnMore.Text = "More";
            this.btnMore.UseVisualStyleBackColor = true;
            this.btnMore.Click += new System.EventHandler(this.btnMore_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnSave.Location = new System.Drawing.Point(83, -3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 43);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnHacker
            // 
            this.btnHacker.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.btnHacker.Location = new System.Drawing.Point(270, -3);
            this.btnHacker.Name = "btnHacker";
            this.btnHacker.Size = new System.Drawing.Size(110, 43);
            this.btnHacker.TabIndex = 37;
            this.btnHacker.Text = "Crack Wi-Fi";
            this.btnHacker.UseVisualStyleBackColor = true;
            this.btnHacker.Click += new System.EventHandler(this.btnHacker_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.BackColor = System.Drawing.Color.ForestGreen;
            this.txtOutput.Location = new System.Drawing.Point(-4, 39);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(806, 415);
            this.txtOutput.TabIndex = 38;
            this.txtOutput.Text = "";
            // 
            // pnlMore
            // 
            this.pnlMore.BackColor = System.Drawing.Color.Blue;
            this.pnlMore.Controls.Add(this.button2);
            this.pnlMore.Controls.Add(this.button1);
            this.pnlMore.Controls.Add(this.cBh);
            this.pnlMore.Controls.Add(this.button8);
            this.pnlMore.Controls.Add(this.button9);
            this.pnlMore.Controls.Add(this.button10);
            this.pnlMore.Controls.Add(this.button11);
            this.pnlMore.Controls.Add(this.button12);
            this.pnlMore.Controls.Add(this.button13);
            this.pnlMore.Controls.Add(this.button14);
            this.pnlMore.Location = new System.Drawing.Point(478, 39);
            this.pnlMore.Name = "pnlMore";
            this.pnlMore.Size = new System.Drawing.Size(324, 411);
            this.pnlMore.TabIndex = 39;
            this.pnlMore.Visible = false;
            // 
            // button2
            // 
            this.button2.Image = global::CsabaNotepadSave_Hacker_.Properties.Resources.Blue;
            this.button2.Location = new System.Drawing.Point(26, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(223, 40);
            this.button2.TabIndex = 30;
            this.button2.Text = "Connect to WarRobots";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button1.Location = new System.Drawing.Point(12, 104);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 40);
            this.button1.TabIndex = 29;
            this.button1.Text = "Open .tsv";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // cBh
            // 
            this.cBh.AutoSize = true;
            this.cBh.Location = new System.Drawing.Point(26, 63);
            this.cBh.Name = "cBh";
            this.cBh.Size = new System.Drawing.Size(154, 24);
            this.cBh.TabIndex = 28;
            this.cBh.Text = "Hack network Pc";
            this.cBh.UseVisualStyleBackColor = true;
            this.cBh.CheckedChanged += new System.EventHandler(this.cBh_CheckedChanged);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button8.Location = new System.Drawing.Point(3, 265);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(188, 49);
            this.button8.TabIndex = 27;
            this.button8.Text = "Save .htmlHacker file";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button9.Location = new System.Drawing.Point(133, 210);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(188, 49);
            this.button9.TabIndex = 26;
            this.button9.Text = "Save .hacker file";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button10.Location = new System.Drawing.Point(181, 54);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(129, 40);
            this.button10.TabIndex = 25;
            this.button10.Text = "Vip";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button11.Location = new System.Drawing.Point(3, 155);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(188, 49);
            this.button11.TabIndex = 24;
            this.button11.Text = "Borowse .htmlHacker file";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button12.Location = new System.Drawing.Point(122, 100);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(188, 49);
            this.button12.TabIndex = 23;
            this.button12.Text = "Borowse .hacker file";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button13.Location = new System.Drawing.Point(26, 8);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(129, 40);
            this.button13.TabIndex = 4;
            this.button13.Text = "Administrator";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.button14.Location = new System.Drawing.Point(181, 7);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(129, 41);
            this.button14.TabIndex = 3;
            this.button14.Text = "Normal";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // CsabaNotepadSaveHacker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CsabaNotepadSave_Hacker_.Properties.Resources.Green;
            this.ClientSize = new System.Drawing.Size(797, 450);
            this.Controls.Add(this.pnlMore);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.btnHacker);
            this.Controls.Add(this.btnBorowse);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnMore1);
            this.Controls.Add(this.btnMore);
            this.Controls.Add(this.btnSave);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CsabaNotepadSaveHacker";
            this.Text = "CsabaNotepadSave(Hacker)";
            this.pnlMore.ResumeLayout(false);
            this.pnlMore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBorowse;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnMore1;
        private System.Windows.Forms.Button btnMore;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnHacker;
        private System.Windows.Forms.RichTextBox txtOutput;
        private System.Windows.Forms.Panel pnlMore;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.CheckBox cBh;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

