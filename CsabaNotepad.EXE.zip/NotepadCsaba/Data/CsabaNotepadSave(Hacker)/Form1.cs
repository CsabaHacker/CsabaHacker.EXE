﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsabaNotepadSave_Hacker_
{
    public partial class CsabaNotepadSaveHacker : Form
    {
        public CsabaNotepadSaveHacker()
        {
            InitializeComponent();
        }

        private void btnMore_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = true;
            btnMore1.Visible = true;
            btnMore.Visible = false;
        }

        private void btnMore1_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = false;
            btnMore1.Visible = false;
            btnMore.Visible = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.txt)|*.txt";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void btnBorowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.txt)|*.txt";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.hacker)|*.hacker";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.htmlHacker)|*.htmlHacker";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave(Vip)\\bin\\Debug\\CsabaNotepadSave(Vip).exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave(Administrator)\\bin\\Debug\\CsabaNotepadSave(Administrator).exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave\\bin\\Debug\\CsabaNotepadSave.exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.hacker)|*.hacker";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.htmlHacker)|*.htmlHacker";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void btnHacker_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("cmd.exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave\\bin\\Debug\\CsabaNotepadSave.exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave(Administrator)\\bin\\Debug\\CsabaNotepadSave(Administrator).exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\ASUS\\source\\repos\\CsabaNotepadSave\\CsabaNotepadSave(Vip)\\bin\\Debug\\CsabaNotepadSave(Vip).exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.hacker)|*.hacker";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.htmlHacker)|*.htmlHacker";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.hacker)|*.hacker";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.htmlHacker)|*.htmlHacker";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void cBh_CheckedChanged(object sender, EventArgs e)
        {
            txtOutput.Text = "echo off\r\necho color a\r\necho hello\r\npause\r\necho dir/s\r\npause\r\necho 1 send to frend> ReadMe.txt\r\nNotepad ReadMe.txt\r\n";
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.bat)|*.bat";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.tsv)|*.tsv";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("mailrugames://play/0.2002140");
            Close();
        }
    }
}
