﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsabaNotepadSave_Administrator_
{
    public partial class CsabaNotepadSaveAdministrator : Form
    {
        public CsabaNotepadSaveAdministrator()
        {
            InitializeComponent();
        }

        private void btnBorowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Text Files (*.txt)|*.txt";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Your File";
            save.Filter = "Text Files (*.txt)|*.txt";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(File.Create(save.FileName));
                writer.Write(txtOutput.Text);
                writer.Dispose();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
        }

        private void btnMore1_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = false;
            btnMore1.Visible = false;
            btnMore.Visible = true;
        }

        private void btnMore_Click(object sender, EventArgs e)
        {
            pnlMore.Visible = true;
            btnMore1.Visible = true;
            btnMore.Visible = false;
        }

        private void buttonVip_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Program Files (x86)\\NotepadCsaba\\Data\\CsabaNotepadSave(Vip)\\bin\\Debug\\CsabaNotepadSave(Vip).exe");
            System.Windows.Forms.Application.Exit();
        }

        private void btn3dayfreevip_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Program Files (x86)\\NotepadCsaba\\Data\\CsabaNotepadSave\\bin\\Debug\\CsabaNotepadSave.exe");
            System.Windows.Forms.Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Css Files (*.css)|*.css|(*.html)|*.html|(*.py)|*.py|(*.Csaba)|*.Csaba";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Bat Files (*.bat)|*.bat";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Bat Files (*.js)|*.js|(*.json)|*.json";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Ps1 Files (*.ps1)|*.ps1";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Rar Zip Files (*.rar)|*.rar|(*.zip)|*.zip";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Ps1 Files (*.exe)|*.exe";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Pick Your File";
            open.Filter = "Pdf Files (*.pdf)|*.pdf";

            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(File.OpenRead(open.FileName));

                txtOutput.Text = reader.ReadToEnd();
                reader.Dispose();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Visible= false;
        }

        private void btNcsaba_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }
    }
}
