﻿namespace CsabaNotepadSave_Administrator_
{
    partial class CsabaNotepadSaveAdministrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CsabaNotepadSaveAdministrator));
            this.pnlMore = new System.Windows.Forms.Panel();
            this.btNcsaba = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.buttonVip = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn3dayfreevip = new System.Windows.Forms.Button();
            this.btnBorowse = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnMore1 = new System.Windows.Forms.Button();
            this.btnMore = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.panel3 = new System.Windows.Forms.Panel();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.pnlMore.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMore
            // 
            this.pnlMore.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlMore.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.pnlMore.Controls.Add(this.btNcsaba);
            this.pnlMore.Controls.Add(this.button6);
            this.pnlMore.Controls.Add(this.button7);
            this.pnlMore.Controls.Add(this.button8);
            this.pnlMore.Controls.Add(this.button5);
            this.pnlMore.Controls.Add(this.button4);
            this.pnlMore.Controls.Add(this.button2);
            this.pnlMore.Controls.Add(this.button3);
            this.pnlMore.Controls.Add(this.buttonVip);
            this.pnlMore.Controls.Add(this.button1);
            this.pnlMore.Controls.Add(this.btn3dayfreevip);
            this.pnlMore.Location = new System.Drawing.Point(522, 38);
            this.pnlMore.Name = "pnlMore";
            this.pnlMore.Size = new System.Drawing.Size(280, 415);
            this.pnlMore.TabIndex = 23;
            // 
            // btNcsaba
            // 
            this.btNcsaba.Image = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.btNcsaba.Location = new System.Drawing.Point(148, 269);
            this.btNcsaba.Name = "btNcsaba";
            this.btNcsaba.Size = new System.Drawing.Size(129, 52);
            this.btNcsaba.TabIndex = 24;
            this.btNcsaba.Text = "cmd.csaba";
            this.btNcsaba.UseVisualStyleBackColor = true;
            this.btNcsaba.Click += new System.EventHandler(this.btNcsaba_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button6.Location = new System.Drawing.Point(13, 235);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(129, 52);
            this.button6.TabIndex = 32;
            this.button6.Text = "Borowse .pdf file";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button7.Location = new System.Drawing.Point(13, 177);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(129, 52);
            this.button7.TabIndex = 31;
            this.button7.Text = "Borowse .rar and .zip file";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button8.Location = new System.Drawing.Point(148, 211);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(129, 52);
            this.button8.TabIndex = 30;
            this.button8.Text = "Borowse .exe File";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button5.Location = new System.Drawing.Point(148, 153);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(129, 52);
            this.button5.TabIndex = 29;
            this.button5.Text = "Borowse .ps1 file";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button4.Location = new System.Drawing.Point(13, 119);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(129, 52);
            this.button4.TabIndex = 28;
            this.button4.Text = "Borowse .js and json file";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button2.Location = new System.Drawing.Point(148, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 52);
            this.button2.TabIndex = 26;
            this.button2.Text = "Borowse .bat File";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button3.Location = new System.Drawing.Point(13, 58);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(129, 55);
            this.button3.TabIndex = 27;
            this.button3.Text = "Borowse .css file";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonVip
            // 
            this.buttonVip.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.buttonVip.Location = new System.Drawing.Point(148, 3);
            this.buttonVip.Name = "buttonVip";
            this.buttonVip.Size = new System.Drawing.Size(129, 39);
            this.buttonVip.TabIndex = 25;
            this.buttonVip.Text = "Vip";
            this.buttonVip.UseVisualStyleBackColor = true;
            this.buttonVip.Click += new System.EventHandler(this.buttonVip_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.button1.Location = new System.Drawing.Point(148, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 41);
            this.button1.TabIndex = 24;
            this.button1.Text = "Normal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn3dayfreevip
            // 
            this.btn3dayfreevip.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.btn3dayfreevip.Location = new System.Drawing.Point(13, 3);
            this.btn3dayfreevip.Name = "btn3dayfreevip";
            this.btn3dayfreevip.Size = new System.Drawing.Size(129, 49);
            this.btn3dayfreevip.TabIndex = 23;
            this.btn3dayfreevip.Text = "3 Day For Free Vip";
            this.btn3dayfreevip.UseVisualStyleBackColor = true;
            this.btn3dayfreevip.Click += new System.EventHandler(this.btn3dayfreevip_Click);
            // 
            // btnBorowse
            // 
            this.btnBorowse.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.btnBorowse.Location = new System.Drawing.Point(-4, -3);
            this.btnBorowse.Name = "btnBorowse";
            this.btnBorowse.Size = new System.Drawing.Size(92, 43);
            this.btnBorowse.TabIndex = 22;
            this.btnBorowse.Text = "Borowse";
            this.btnBorowse.UseVisualStyleBackColor = true;
            this.btnBorowse.Click += new System.EventHandler(this.btnBorowse_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.btnClear.Location = new System.Drawing.Point(177, -3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(99, 43);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnMore1
            // 
            this.btnMore1.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.btnMore1.Location = new System.Drawing.Point(697, -3);
            this.btnMore1.Name = "btnMore1";
            this.btnMore1.Size = new System.Drawing.Size(105, 43);
            this.btnMore1.TabIndex = 20;
            this.btnMore1.Text = "More";
            this.btnMore1.UseVisualStyleBackColor = true;
            this.btnMore1.Click += new System.EventHandler(this.btnMore1_Click);
            // 
            // btnMore
            // 
            this.btnMore.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.btnMore.Location = new System.Drawing.Point(700, -3);
            this.btnMore.Name = "btnMore";
            this.btnMore.Size = new System.Drawing.Size(105, 43);
            this.btnMore.TabIndex = 19;
            this.btnMore.Text = "More";
            this.btnMore.UseVisualStyleBackColor = true;
            this.btnMore.Click += new System.EventHandler(this.btnMore_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Blue;
            this.btnSave.Location = new System.Drawing.Point(83, -3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 43);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.BackColor = System.Drawing.Color.ForestGreen;
            this.txtOutput.Location = new System.Drawing.Point(-4, 38);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(809, 415);
            this.txtOutput.TabIndex = 17;
            this.txtOutput.Text = "";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Dark;
            this.panel1.Controls.Add(this.progressBar5);
            this.panel1.Controls.Add(this.progressBar4);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Location = new System.Drawing.Point(-4, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 456);
            this.panel1.TabIndex = 24;
            this.panel1.Visible = false;
            // 
            // progressBar5
            // 
            this.progressBar5.Location = new System.Drawing.Point(39, 89);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(100, 26);
            this.progressBar5.Step = 1;
            this.progressBar5.TabIndex = 7;
            this.progressBar5.Value = 100;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(672, 89);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(100, 26);
            this.progressBar4.Step = 1;
            this.progressBar4.TabIndex = 6;
            this.progressBar4.Value = 100;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(39, 302);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(733, 26);
            this.progressBar1.Step = 1;
            this.progressBar1.TabIndex = 1;
            this.progressBar1.Value = 100;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.progressBar3);
            this.panel3.Location = new System.Drawing.Point(749, 160);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(23, 144);
            this.panel3.TabIndex = 5;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(0, 0);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(23, 144);
            this.progressBar3.Step = 1;
            this.progressBar3.TabIndex = 2;
            this.progressBar3.Value = 100;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.progressBar2);
            this.panel2.Location = new System.Drawing.Point(39, 160);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(23, 144);
            this.panel2.TabIndex = 4;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(0, 0);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(23, 144);
            this.progressBar2.Step = 1;
            this.progressBar2.TabIndex = 1;
            this.progressBar2.Value = 100;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(672, 89);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(39, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(39, 302);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(733, 26);
            this.textBox1.TabIndex = 1;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Red;
            this.button9.Location = new System.Drawing.Point(755, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(54, 38);
            this.button9.TabIndex = 0;
            this.button9.Text = "X";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // CsabaNotepadSaveAdministrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.BackgroundImage = global::CsabaNotepadSave_Administrator_.Properties.Resources.Green;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlMore);
            this.Controls.Add(this.btnBorowse);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnMore1);
            this.Controls.Add(this.btnMore);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtOutput);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CsabaNotepadSaveAdministrator";
            this.Text = "CsabaNotepadSave(Administrator)";
            this.pnlMore.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMore;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button buttonVip;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn3dayfreevip;
        private System.Windows.Forms.Button btnBorowse;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnMore1;
        private System.Windows.Forms.Button btnMore;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.RichTextBox txtOutput;
        private System.Windows.Forms.Button btNcsaba;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}

